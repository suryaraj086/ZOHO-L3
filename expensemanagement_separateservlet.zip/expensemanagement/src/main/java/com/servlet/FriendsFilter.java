package com.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.exception.CustomException;
import com.expensemanagement.Manager;
import com.expensemanagement.datastore.User;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;


@WebServlet("/FriendsFilter")
public class FriendsFilter extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
 
    public FriendsFilter() {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("filter");
		JSONObject obj = null;
		try {
			obj = getJson(request);
		} catch (IOException | org.json.simple.parser.ParseException e) {
			e.printStackTrace();
		}
		String page=(String)obj.get("page");
		Manager manager = (Manager) request.getServletContext().getAttribute("logic");
		if (page.equals("filter_all")) {
			Map<Integer, User> user = manager.getUserMap();
			List<User> userList = new ArrayList<>();
			for (User userObj : user.values()) {
				userList.add(userObj);
			}
			Gson gson = new Gson();
			String element = gson.toJson(userList, new TypeToken<ArrayList<User>>() {
			}.getType());
			response.getWriter().write(element);
		} else if (page.equals("filter_friends")) {
			try {
				HttpSession session = request.getSession();
				int iden = (int) session.getAttribute("userId");
				List<Integer> friends = manager.getFriendsList(iden);
				List<User> user = getUserFromFriendList(friends, manager);
				Gson gson = new Gson();
				String element = gson.toJson(user, new TypeToken<ArrayList<User>>() {
				}.getType());
				response.getWriter().write(element);
			} catch (CustomException e) {
				response.getWriter()
						.write("http://localhost:8080/expensemanagement/AddFriends.jsp?message=" + e.getMessage());
			}
		} else if (page.equals("filter_not_friends")) {
			try {
				HttpSession session = request.getSession();
				int iden = (int) session.getAttribute("userId");
				List<Integer> friends = manager.getFriendsList(iden);
				List<User> user = getUserWithoutFriendList(friends, manager);
				Gson gson = new Gson();
				String element = gson.toJson(user, new TypeToken<ArrayList<User>>() {
				}.getType());
				response.getWriter().write(element);
			} catch (CustomException e) {
				response.getWriter()
						.write("http://localhost:8080/expensemanagement/AddFriends.jsp?message=" + e.getMessage());
			}
		} 
	}
	
	public List<User> getUserFromFriendList(List<Integer> friends, Manager manager) throws CustomException {
		List<User> friendsObj = new ArrayList<>();
		if (friends == null) {
			return friendsObj;
		}
		for (int i = 0; i < friends.size(); i++) {
			friendsObj.add(manager.getUser(friends.get(i)));
		}
		return friendsObj;
	}
	

	public List<User> getUserWithoutFriendList(List<Integer> friends, Manager manager) throws CustomException {
		List<User> users = new ArrayList<>();

		Map<Integer, User> userMap = manager.getUserMap();
		for (int userId : userMap.keySet()) {
			if (friends == null || !friends.contains(userId)) {
				users.add(userMap.get(userId));
			}
		}
		return users;
	}

	private JSONObject getJson(HttpServletRequest request) throws IOException, org.json.simple.parser.ParseException {
		BufferedReader readerObj = request.getReader();
		StringBuilder builderObj = new StringBuilder();
		String line = null;
		while ((line = readerObj.readLine()) != null) {
			builderObj.append(line);
			System.out.println(line);
		}
		return (JSONObject) new JSONParser().parse(builderObj.toString());
	}

}
