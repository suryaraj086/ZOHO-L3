package com.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.exception.CustomException;
import com.expensemanagement.Manager;
import com.expensemanagement.datastore.User;


@WebServlet("/SignUpAction")
public class SignUpAction extends HttpServlet {
	private static final long serialVersionUID = 1L;


	public SignUpAction() {
		super();
		// TODO Auto-generated constructor stub
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		JSONObject obj = null;
		try {
			obj = getJson(request);
		} catch (IOException | org.json.simple.parser.ParseException e) {
			e.printStackTrace();
		}
		Manager manager = (Manager) request.getServletContext().getAttribute("logic");
		String name = (String) obj.get("name");
		String email = (String) obj.get("email");
		String phone = (String) obj.get("phonenumber");
		String pass = (String) obj.get("password");
		try {
			nullChecker(pass);
			nullChecker(phone);
			nullChecker(email);
			nullChecker(name);
			long phoneNo = Long.parseLong(phone);
			int userId = manager.generateUserId();
			User user = new User(name, userId, email, phoneNo, pass);
			manager.addNewUser(user);
			response.getWriter()
					.write("http://localhost:8080/expensemanagement/Login.jsp?message=your user id is " + userId);
			return;
		} catch (Exception e) {
			response.getWriter().write("http://localhost:8080/expensemanagement/Login.jsp?message=" + e.getMessage());
		}

	}

	public void nullChecker(Object val) throws CustomException {
		if (val == null || val.equals("")) {
			throw new CustomException("Field cannot be empty");
		}
	}

	private JSONObject getJson(HttpServletRequest request) throws IOException, org.json.simple.parser.ParseException {
		BufferedReader readerObj = request.getReader();
		StringBuilder builderObj = new StringBuilder();
		String line = null;
		while ((line = readerObj.readLine()) != null) {
			builderObj.append(line);
			System.out.println(line);
		}
		return (JSONObject) new JSONParser().parse(builderObj.toString());
	}

}
