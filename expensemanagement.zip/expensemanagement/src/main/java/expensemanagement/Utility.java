package expensemanagement;

public class Utility {

}
