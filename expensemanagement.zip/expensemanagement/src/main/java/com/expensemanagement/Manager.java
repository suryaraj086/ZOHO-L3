package com.expensemanagement;

import java.util.List;
import java.util.Map;

import com.exception.CustomException;
import com.expensemanagement.datastore.*;

public class Manager {
	private Connector db = null;
	private ExpenseManager exp = null;

	public Manager() throws Exception {
		db = new DBLayer();
		exp = new ExpenseManager();
	}

	public int generateUserId() {
		return exp.generateUserId();
	}

	public int generateTripId() {
		return exp.generateTripId();
	}

	public int generateExpenseId() {
		return exp.generateExpenseId();
	}

	public void addNewFriend(int userId, int friendId) throws CustomException {
		exp.addNewFriend(userId, friendId);
		db.addNewFriend(userId, friendId);
	}

	public void addNewUser(User user) throws Exception {
		exp.addNewUser(user);
		db.addNewUser(user);
	}

	public boolean login(int userId, String password) throws CustomException {
		return exp.login(userId, password);
	}

	public List<Integer> getFriendsList(int userId) {
		return exp.getFriendsList(userId);
	}

	public void addNewTrip(Trip trip) throws CustomException {
		exp.addNewTrip(trip);
		db.addNewTrip(trip);
	}

	public boolean checkFriendsList(int userId, int friendsId) throws CustomException {
		return exp.checkFriendsList(userId, friendsId);
	}

	public void addMemberToTrip(int fromId, int toId, int tripId) throws CustomException {

		exp.addMemberToTrip(fromId, toId, tripId);
		db.addNewMember(toId, tripId);
	}

	public void addExpense(Expense expense) throws CustomException {

		exp.addExpense(expense);
		db.addNewExpense(expense.getFromUserId(), expense.getToUserId(), expense.getTripId(), expense.getAmount(),
				expense.getDescription(), expense.getExpenseId());

	}

	public List<Integer> getTripFriends(int tripId) throws CustomException {
		return exp.getTripFriends(tripId);
	}

	public void payAllExpense(int userId) throws CustomException {
		exp.payAllExpense(userId);
		db.payAllOweAmount(userId);
	}

	public void payIndividualExpense(int fromUser, int toUser, int amount, int tripId, int expenseId) throws CustomException {

		exp.payIndividualExpense(fromUser, toUser, amount, expenseId);
		db.payOweAmount(fromUser, toUser, tripId, amount, expenseId);

	}

	public String showOweAmount(int userId) {
		return exp.showOweAmount(userId);
	}

	public Map<Integer, User> getUserMap() {
		return exp.getUserMap();
	}

}
