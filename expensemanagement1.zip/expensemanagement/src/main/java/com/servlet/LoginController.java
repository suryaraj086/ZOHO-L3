package com.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.exception.CustomException;
import com.expensemanagement.*;
import com.expensemanagement.datastore.*;
import org.json.simple.*;
import org.json.simple.parser.JSONParser;

@WebServlet("/LoginController")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public LoginController() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	@SuppressWarnings("deprecation")
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		JSONObject obj = null;
		try {
			obj = getJson(request);
		} catch (IOException | org.json.simple.parser.ParseException e) {
			e.printStackTrace();
		}

		String id = (String) obj.get("id");
		String password = (String) obj.get("password");
		String page = (String) obj.get("page");
		Manager manager = (Manager) request.getServletContext().getAttribute("logic");
		Map<Integer, User> userMap = manager.getUserMap();
		request.setAttribute("LoginController", userMap);

		try {

			if (page == null && id != null && password != null && !id.isEmpty() && !password.isEmpty()
					&& manager.login(Integer.parseInt(id), password)) {
				int uId = Integer.parseInt(id);
				HttpSession session = request.getSession();
				session.setAttribute("userId", uId);
				response.getWriter().write("http://localhost:8080/expensemanagement/AddFriends.jsp");
				return;
			}
		} catch (Exception e) {
			e.printStackTrace();
			response.getWriter().write("http://localhost:8080/expensemanagement/Login.jsp?message=" + e.getMessage());
			return;
		}

		if (page != null) {
			if (page.trim().equals("Add to friends list")) {
				JSONArray arr = (JSONArray) obj.get("friendslist");
				HttpSession session = request.getSession();
				int iden = (int) session.getAttribute("userId");
				try {
					if (arr == null || arr.size() == 0) {
						throw new CustomException("Select member to add to friends list");
					}
					addToList(arr, iden, manager);
					response.getWriter()
							.write("http://localhost:8080/expensemanagement/AddFriends.jsp?message=friends added");

				} catch (Exception e) {
					response.getWriter()
							.write("http://localhost:8080/expensemanagement/AddFriends.jsp?message=" + e.getMessage());
				}

			} else if (page.equals("added trip")) {

				int tripId = manager.generateTripId();
				String tripName = (String) obj.get("tripname");
				String startDate = (String) obj.get("startdate");
				String endDate = (String) obj.get("enddate");
				JSONArray arr = (JSONArray) obj.get("friendslist");
				SimpleDateFormat f = new SimpleDateFormat("yyyy-mm-dd");

				try {
					if (arr == null || arr.isEmpty()) {
						throw new CustomException("Select friends for trip");
					}
					nullChecker(tripId);
					nullChecker(startDate);
					nullChecker(endDate);
					nullChecker(tripName);
					Date d = f.parse(startDate);
					Date d1 = f.parse(endDate);
					long frommilliseconds = d.getTime();
					long tomilliseconds = d1.getTime();
					HttpSession session = request.getSession();
					int iden = (int) session.getAttribute("userId");
					Trip trip = new Trip(tripId, tripName, frommilliseconds, tomilliseconds);
					manager.addNewTrip(trip);
					addNewTripMembers(arr, iden, tripId, manager);
					response.getWriter()
							.write("http://localhost:8080/expensemanagement/AddTrip.jsp?message=added trip");
				} catch (Exception e) {

					response.getWriter()
							.write("http://localhost:8080/expensemanagement/AddTrip.jsp?message= " + e.getMessage());
				}

			} else if (page.equals("remove from friends list")) {

				HttpSession session = request.getSession();
				int iden = (int) session.getAttribute("userId");
				JSONArray arr = (JSONArray) obj.get("friendslist");
				try {
					if (arr == null || arr.isEmpty()) {
						throw new CustomException("Select friends to remove");
					}
					removeFromFriendsList(arr, iden, manager);
					response.getWriter().write(
							"http://localhost:8080/expensemanagement/AddFriends.jsp?message=removed successfully");
				} catch (CustomException e) {
					response.getWriter()
							.write("http://localhost:8080/expensemanagement/AddFriends.jsp?message=" + e.getMessage());
				}
			} else if (page.equals("Add Friends")) {

				response.getWriter().write("http://localhost:8080/expensemanagement/AddFriends.jsp");

			} else if (page.equals("Add Trip")) {

				response.getWriter().write("http://localhost:8080/expensemanagement/AddTrip.jsp");

			} else if (page.equals("Add Expenses")) {

				response.getWriter().write("http://localhost:8080/expensemanagement/AddExpense.jsp");

			} else if (page.equals("Add new expense")) {

				String tripId = (String) obj.get("tripid");
				String amount = (String) obj.get("amount");
				String description = (String) obj.get("description");
				JSONArray arr = (JSONArray) obj.get("friendslist");
				HttpSession session = request.getSession();
				int iden = (int) session.getAttribute("userId");
				try {
					nullChecker(arr);
					nullChecker(tripId);
					nullChecker(amount);
					addNewExpense(arr, iden, manager, Float.parseFloat(amount), description, Integer.parseInt(tripId));
					response.getWriter().write(
							"http://localhost:8080/expensemanagement/AddExpense.jsp?message=Expense added successfully");
				} catch (Exception e) {
					e.printStackTrace();
					response.getWriter()
							.write("http://localhost:8080/expensemanagement/AddExpense.jsp?message= " + e.getMessage());
				}

			} else if (page.equals("Amount spent")) {

				HttpSession session = request.getSession();
				int iden = (int) session.getAttribute("userId");
				String out = manager.showOweAmount(iden);
				
				response.getWriter().write(out);
				response.getWriter().write("http://localhost:8080/expensemanagement/AmountSpend.jsp");

			} else if (page.equals("List Trip")) {

				response.getWriter().write("http://localhost:8080/expensemanagement/TripList.jsp");

			} else if (page.equals("Return owed amount")) {

				HttpSession session = request.getSession();
				int iden = (int) session.getAttribute("userId");
				String out = manager.showOweAmount(iden);
				response.getWriter()
						.write("http://localhost:8080/expensemanagement/ReturnOweAmount.jsp?message=" + out);

			} else if (page.equals("tripid for expense")) {

				String tripid = (String) obj.get("tripid");
				response.getWriter().write("http://localhost:8080/expensemanagement/AddExpense.jsp?tripid=" + tripid);

			} else if (page.equals("repay all")) {

				HttpSession session = request.getSession();
				int iden = (int) session.getAttribute("userId");
				try {
					manager.payAllExpense(iden);
					response.getWriter().write(
							"http://localhost:8080/expensemanagement/ReturnOweAmount.jsp?message=repay successful");
				} catch (CustomException e) {
					response.getWriter().write(
							"http://localhost:8080/expensemanagement/ReturnOweAmount.jsp?message=" + e.getMessage());
					e.printStackTrace();
				}

			} else if (page.equals("repay individual owe amount")) {
				HttpSession session = request.getSession();
				int iden = (int) session.getAttribute("userId");
				String expId = (String) obj.get("expenseid");
				String userId = (String) obj.get("userid");
				try {
					nullChecker(expId);
					nullChecker(userId);
					manager.payIndividualExpense(iden, Integer.parseInt(userId), Integer.parseInt(expId));
					response.getWriter().write(
							"http://localhost:8080/expensemanagement/ReturnOweAmount.jsp?message=repay successful");
				} catch (NumberFormatException | CustomException e) {
					e.printStackTrace();
					response.getWriter().write(
							"http://localhost:8080/expensemanagement/ReturnOweAmount.jsp?message=" + e.getMessage());
				}
			}

			else if (page.equals("Logout")) {

				HttpSession session = request.getSession();
				session.invalidate();
				response.getWriter().write("http://localhost:8080/expensemanagement/Login.jsp");

			} else if (page.equals("signup")) {

				String name = (String) obj.get("name");
				String email = (String) obj.get("email");
				String phone = (String) obj.get("phonenumber");
				String pass = (String) obj.get("password");
				try {
					nullChecker(pass);
					nullChecker(phone);
					nullChecker(email);
					nullChecker(name);
					long phoneNo = Long.parseLong(phone);
					int userId = manager.generateUserId();
					User user = new User(name, userId, email, phoneNo, pass);
					manager.addNewUser(user);
					System.out.println("signup");
					response.getWriter()
							.write("http://localhost:8080/expensemanagement/Login.jsp?message=user id is " + userId);
				} catch (Exception e) {
					response.getWriter()
							.write("http://localhost:8080/expensemanagement/Login.jsp?message=" + e.getMessage());
				}
			}
		}
	}

	public void nullChecker(Object val) throws CustomException {
		if (val == null || val.equals("")) {
			throw new CustomException("Field cannot be empty");
		}
	}

	public void addToList(JSONArray arr, int id, Manager manager) throws NumberFormatException, Exception {
		for (int i = 0; i < arr.size(); i++) {
			manager.addNewFriend(id, Integer.parseInt((String) arr.get(i)));
		}
	}

	public void addNewExpense(JSONArray arr, int id, Manager manager, float amount, String description, int tripId)
			throws NumberFormatException, Exception {
		for (int i = 0; i < arr.size(); i++) {
			if (id != Integer.parseInt((String) arr.get(i))) {
				Expense exp = new Expense(id, Integer.parseInt((String) arr.get(i)), amount / (arr.size()), description,
						tripId, manager.generateExpenseId());
				manager.addExpense(exp);
			}
		}
	}

	public void addNewTripMembers(JSONArray arr, int id, int tripId, Manager manager) throws CustomException {
		manager.addMemberToTrip(id, id, tripId);
		for (int i = 0; i < arr.size(); i++) {
			manager.addMemberToTrip(id, Integer.parseInt((String) arr.get(i)), tripId);
		}
	}

	public void removeFromFriendsList(JSONArray arr, int userId, Manager manager) throws CustomException {
		for (int i = 0; i < arr.size(); i++) {
			nullChecker(arr.get(i));
			manager.removeFromFriendsList(userId, Integer.parseInt((String) arr.get(i)));
		}
	}

	private JSONObject getJson(HttpServletRequest request) throws IOException, org.json.simple.parser.ParseException {
		BufferedReader readerObj = request.getReader();
		StringBuilder builderObj = new StringBuilder();
		String line = null;
		while ((line = readerObj.readLine()) != null) {
			builderObj.append(line);
			System.out.println(line);
		}
		return (JSONObject) new JSONParser().parse(builderObj.toString());
	}

	public void init(ServletConfig config) {
		try {
			super.init(config);
			Manager logicLayer = new Manager();
			config.getServletContext().setAttribute("logic", logicLayer);
		} catch (Exception e) {
			e.printStackTrace();
		}
		config.getServletContext();

	}

}