function myFunction() {
	$(document).ready(function() {
		$("#myInput").on("keyup", function() {
			var value = $(this).val().toLowerCase();
			$("#customers tr").filter(function() {
				$(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
			});
		});
	});
}

function my() {
	var input, filter, table, tr, td, i, txtValue;
	input = document.getElementById("myInput");
	filter = input.value.toUpperCase();
	table = document.getElementById("customers");
	tr = table.getElementsByTagName("tr");
	for (i = 0; i < tr.length; i++) {
		td = tr[i].getElementsByTagName("td")[0];
		if (td) {
			txtValue = td.textContent || td.innerText;
			if (txtValue.toUpperCase().indexOf(filter) > -1) {
				tr[i].style.display = "";
			} else {
				tr[i].style.display = "none";
			}
		}
	}

}

function close() {
	document.getElementById('alert').style.display = 'none';
}

function validateemail() {
	var x = document.getElementById('email').value;
	var atposition = x.indexOf("@");
	var dotposition = x.lastIndexOf(".");
	if (atposition < 1 || dotposition < atposition + 2 || dotposition + 2 >= x.length) {
		alert("Please enter a valid e-mail address");
		return false;
	}
}


function validatePassword() {
	var password = document.getElementById('password').value;
	var val = 0;
	for (var i = 0; i < password.length; i++) {
		if (isNaN(password.charAt(i)) && password.charAt(i) == password.charAt(i).toUpperCase()) {
			val++;
		}
	}
	if (val == 0) {
		alert("password should have one uppercase character");
		return false;
	}
	if (password.length < 8) {
		alert("Password must be greater than 8 characters");
		return false;
	}
}

